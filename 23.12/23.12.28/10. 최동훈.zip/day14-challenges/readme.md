# 피그마 링크
https://www.figma.com/file/Yc3Vek0CDh5LAOY2qIGVoq/ZIGZAG/duplicate

# 텍스트 
```

START YOUR
PORTFOLIO
PROJECT



Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled



Rest

Take a rest

It has survived not only five centuries.

Why do we use it?

Contrary to popular belief, Lorem Ipsum is not simply random text. It has root.



Craft

Build something

There are many variations of passages of Lorem Ipsum available.

If you are going to use a passage of Lorem Ipsum.

The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.



Scrap

Reference

Once is therefore always free form repetition, injected humor, or non-characterisic words etc.

Predefined chunks as necessary, making this the first true generator on the internet.

Finibus Bonorum et Malorum by Cicero are also reproduced in their exact original form.
```
